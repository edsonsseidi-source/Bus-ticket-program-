# Bus Ticket Purchase System

## Project Overview
This project is a Python-based bus ticket purchase system developed for the COMP10121 module.  
The program runs in the command line and allows users to load ticket data from a CSV file, view available ticket categories and top-ups, purchase tickets, and save those purchases so they persist between program runs.
The system was developed incrementally following a set of defined use cases, with each use case adding new functionality to the program.


## How to Run
Ensure  main.py , tickets.csv , and (if present) Purchases.csv are in the same directory.
2. Open main.py using Python IDLE.
3. Press "F5" to run the program.
4. Follow the on-screen prompts to:
   - View ticket categories
   - Select ticket types
   - Confirm purchases
   - Exit the program
     Purchased tickets will automatically be saved when the program ends.

# Use Case Descriptions
UC1 – Load Ticket Data
The program loads ticket data from a CSV file into a list of dictionaries. Each row represents a ticket option with its category, top-up type, and price.

UC2 – Extract Ticket Categories 
Unique ticket categories are extracted from the loaded data and displayed to the user in a sorted list.

UC3 – Display Top-Ups for a Category 
When a category is selected, all available top-up options for that category are displayed.

UC4 – Show Top-Up Details  
The user can view detailed information (such as price) for a selected top-up.

UC5 – Purchase Flow  
The user selects a category and top-up, confirms the purchase, and the purchase is recorded as a dictionary. Multiple purchases can be made in one session.

UC6 – Save Purchases  
All purchases made during the session are saved to a CSV file (purchases.csv) so they can be reused later.

UC7 – Load Previous Purchases  
When the program starts, any existing purchases are loaded from purchases.csv and added to the current session.

# Testing Strategy
The program was tested throughout development using Python IDLE.  
Testing included:
- Running the program multiple times to ensure purchases persist correctly and consistently 
- Making multiple purchases in one session
- i'd test invalid user input (e.g. entering letters instead of numbers)
- i was consitently Confirming the program does not crash when files are missing or empty
Additionally, frequent GitHub commits were used to track progress and test individual use cases incrementally.

## Critique and Reflection
This project helped reinforce key Python skills needed to do well on this modulee such as functions, loops, dictionaries, lists, and file handling.  
One challenge i encountered was handling CSV files with inconsistent formatting, which required additional validation and cleaning of data. Another challenge was managing program flow and indentation, which improved my understanding of Python’s structure.

## Academic Integrity and AI Use
AI-based tools were used to support understanding of Python concepts, debugging errors, and structuring some of my program logic.  
All code was reviewed, adapted, tested, and understood by me and my friends over the holiday , i can explain how the program works and justify the design decisions made.
